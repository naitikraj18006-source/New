# Ramu: APK kaise banayein (bilkul free, sirf phone se)

## Step 1: GitHub par project daalo
1. github.com par free account banao / login karo.
2. Naya repository banao (naam: `ramu`, Private rakho).
3. "uploading an existing file" par jao aur is zip ke **andar ke saare files aur folders** upload karo
   (`.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`).
   Dhyan do: `.github` folder bhi upload hona chahiye.
   (Phone se folder upload na ho to zip ko pehle extract karo, ya laptop/cyber cafe se upload karo.)

## Step 2: APK banwao
1. Repository mein **Actions** tab kholo.
2. "Ramu APK banao" chuno, phir **Run workflow** dabao.
3. 5-10 minute mein hara tick aayega. Us run par click karo, neeche **Ramu-apk** milega, download karo.
4. Zip extract karke `app-release.apk` ko phone mein install karo ("Unknown source" allow karna padega).
5. Agar build fail ho, to error ka text mujhe bhejo, main theek kar dunga.

## Step 3: Ramu ko set karo (app ke andar, upar se neeche)
1. **Gemini API key**: aistudio.google.com par Google account se login karke "Get API key" dabao. Free hai. Key app mein daalo.
2. **Keys save karo** dabao.
3. **Model download karo** (ek baar, ~36 MB, Wi-Fi par karo).
4. **Permissions do**: mic, contacts, call.
5. **Display over other apps** allow karo. Iske bina Ramu peeche se app nahi khol payega.
6. **Accessibility on karo**: list mein "Ramu" chuno aur on karo. Ye sirf WhatsApp ka call button aur conference ka Merge button dabane ke kaam aata hai.
7. **Battery optimization band karo**, warna Moto phone Ramu ko band kar dega.
8. **Ramu chalu karo**. Ab bolo: "Ramu".

## Kya bol sakte ho
- "Ramu, Camera kholo" / "Ramu, Settings kholo"
- "Ramu, WhatsApp par Rahul ka chat kholo"
- "Ramu, WhatsApp par Rahul ko call karo" (video ke liye "video call")
- "Ramu, Mummy ko phone lagao"
- "Ramu, Rahul aur Amit ko conference call lagao"
- "Ramu, YouTube par One India ka latest video kholo"
- Koi bhi sawal: "Ramu, India ki rajdhani kya hai?"

## Zaroori baatein (sach-sach)
- Contact ka naam phone mein English letters mein save ho to sabse accha match hota hai.
- WhatsApp call tabhi seedha lagti hai jab contact WhatsApp se synced ho; warna Accessibility chat kholkar call button dabati hai. Kuch WhatsApp versions mein ye button na mile to call nahi lagegi.
- Conference call best-effort hai: pehli call lagne ke ~14 second baad doosri call lagti hai, phir Merge dabta hai. Agar samne wala der se uthaye to Merge chhoot sakta hai.
- YouTube channel ka latest video seedha kholne ke liye YouTube API key chahiye (free, Google Cloud Console se). Bina key ke YouTube mein search khulta hai.
- Privacy: "Ramu" bolne se pehle ki awaaz save ya bheji nahi jaati. Uske baad ka sawal Android ka speech recogniser text banata hai (offline Hindi pack download ho to offline, warna Google ke server par ja sakta hai). Phir sirf text Gemini ko jaata hai.
- Ye code abhi phone par test nahi hua. Pehli baar mein kuch cheezein adjust karni pad sakti hain; jo galat chale mujhe batao.
