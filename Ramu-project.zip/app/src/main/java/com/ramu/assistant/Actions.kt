package com.ramu.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Brain ke diye action ko phone par asli mein karta hai. */
class Actions(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())

    private val WA_VOICE = "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
    private val WA_VIDEO = "vnd.android.cursor.item/vnd.com.whatsapp.video.call"

    /** Returns kuch bolna ho to (error / override jawab), warna null. */
    fun run(cmd: JSONObject, ytKey: String): String? {
        val contacts = cmd.optJSONArray("contacts")?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList()
        return when (cmd.optString("action")) {
            "open_app" -> openApp(cmd.optString("app"))
            "whatsapp_chat" -> contacts.firstOrNull()?.let { whatsappChat(it) } ?: "किसका chat खोलना है?"
            "whatsapp_call" -> contacts.firstOrNull()?.let { whatsappCall(it, false) } ?: "किसे call करना है?"
            "whatsapp_video" -> contacts.firstOrNull()?.let { whatsappCall(it, true) } ?: "किसे video call करना है?"
            "phone_call" -> contacts.firstOrNull()?.let { phoneCall(it) } ?: "किसे call करना है?"
            "conference" -> conference(contacts)
            "youtube" -> youtube(cmd.optString("channel"), cmd.optString("query"), ytKey)
            else -> null
        }
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        main.post { try { ctx.startActivity(i) } catch (_: Exception) {} }
    }

    // ---------- app kholna ----------
    private fun openApp(name: String): String? {
        if (name.isBlank()) return "कौन सा app खोलना है?"
        val pm = ctx.packageManager
        val q = name.lowercase().trim()
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val best = apps.minByOrNull { ri ->
            val label = ri.loadLabel(pm).toString().lowercase()
            when {
                label == q -> 0
                label.contains(q) || q.contains(label) -> 1
                else -> 100 + lev(label, q)
            }
        }
        val label = best?.loadLabel(pm)?.toString()?.lowercase()
        if (best == null || label == null || !(label == q || label.contains(q) || q.contains(label) || lev(label, q) <= 2)) {
            return "$name app मुझे phone में नहीं मिला।"
        }
        val intent = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return "$name नहीं खुल पाया।"
        start(intent)
        return null
    }

    // ---------- contacts ----------
    private fun allContacts(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        )
        c?.use { while (it.moveToNext()) out.add(it.getString(0) to it.getString(1)) }
        return out
    }

    private fun findContact(name: String): Pair<String, String>? {
        val q = name.lowercase().trim()
        val list = allContacts()
        list.firstOrNull { it.first.lowercase() == q }?.let { return it }
        list.firstOrNull { it.first.lowercase().contains(q) }?.let { return it }
        val best = list.minByOrNull { lev(it.first.lowercase().substringBefore(" "), q.substringBefore(" ")) }
        return if (best != null && lev(best.first.lowercase().substringBefore(" "), q.substringBefore(" ")) <= 2) best else null
    }

    private fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("0")) d = d.trimStart('0')
        return if (d.length == 10) "91$d" else d
    }

    // ---------- WhatsApp ----------
    private fun whatsappChat(name: String): String? {
        val c = findContact(name) ?: return "$name नाम का contact नहीं मिला।"
        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${waNumber(c.second)}")).setPackage("com.whatsapp"))
        return null
    }

    private fun whatsappCall(name: String, video: Boolean): String? {
        val c = findContact(name) ?: return "$name नाम का contact नहीं मिला।"
        // Tareeka 1: WhatsApp ka seedha call-row (agar contact WhatsApp se synced hai)
        val mime = if (video) WA_VIDEO else WA_VOICE
        val cur = ctx.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID),
            "${ContactsContract.Data.MIMETYPE}=? AND ${ContactsContract.Data.DISPLAY_NAME}=?",
            arrayOf(mime, c.first), null
        )
        var rowId: Long? = null
        cur?.use { if (it.moveToFirst()) rowId = it.getLong(0) }
        if (rowId != null) {
            start(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse("content://com.android.contacts/data/$rowId"), mime).setPackage("com.whatsapp"))
            return null
        }
        // Tareeka 2: chat kholkar Accessibility se call button dabana
        RamuAccessibility.request(if (video) "wa_video" else "wa_voice", 25)
        start(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${waNumber(c.second)}")).setPackage("com.whatsapp"))
        return null
    }

    // ---------- phone / conference ----------
    private fun phoneCall(name: String): String? {
        val c = findContact(name) ?: return "$name नाम का contact नहीं मिला।"
        start(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(c.second)}")))
        return null
    }

    private fun conference(names: List<String>): String? {
        if (names.size < 2) return "Conference call के लिए कम से कम दो नाम बोलिए।"
        val found = names.map { it to findContact(it) }
        found.firstOrNull { it.second == null }?.let { return "${it.first} नाम का contact नहीं मिला।" }
        val numbers = found.map { it.second!!.second }
        start(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(numbers[0])}")))
        // Best-effort: agli call har ~14 second baad, phir Merge dabana.
        for (i in 1 until numbers.size) {
            main.postDelayed({
                start(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(numbers[i])}")))
            }, 14000L * i)
            main.postDelayed({ RamuAccessibility.request("merge", 25) }, 14000L * i + 9000L)
        }
        return null
    }

    // ---------- YouTube ----------
    private fun youtube(channel: String, query: String, key: String): String? {
        val search = listOf(channel, query).filter { it.isNotBlank() }.joinToString(" ")
        if (search.isBlank()) {
            ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")?.let { start(it) }
            return null
        }
        if (key.isNotBlank() && channel.isNotBlank()) {
            try {
                val chId = yt("search?part=snippet&type=channel&maxResults=1&q=${enc(channel)}", key)
                    .getJSONArray("items").getJSONObject(0).getJSONObject("snippet").getString("channelId")
                val vq = if (query.isNotBlank()) "&q=${enc(query)}" else ""
                val vid = yt("search?part=snippet&type=video&maxResults=1&order=${if (query.isBlank()) "date" else "relevance"}&channelId=$chId$vq", key)
                    .getJSONArray("items").getJSONObject(0).getJSONObject("id").getString("videoId")
                start(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$vid")).setPackage("com.google.android.youtube"))
                return null
            } catch (_: Exception) { /* neeche search par chalte hain */ }
        }
        start(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", search))
        return null
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun yt(path: String, key: String): JSONObject {
        val conn = URL("https://www.googleapis.com/youtube/v3/$path&key=$key").openConnection() as HttpURLConnection
        conn.connectTimeout = 10000; conn.readTimeout = 15000
        return JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
    }

    // ---------- chhota edit-distance (galat sunne par naam match karne ke liye) ----------
    private fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]; dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}
