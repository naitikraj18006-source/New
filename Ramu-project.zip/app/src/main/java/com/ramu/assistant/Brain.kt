package com.ramu.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini (free API key) se sawal ka matlab nikalta hai: kaunsa kaam karna hai aur kya bolna hai. */
object Brain {

    private val history = ArrayList<Pair<String, String>>() // (role, text)

    private const val SYSTEM = """
Tum "Ramu" ho, ek dost jaisa smart personal voice assistant. User India mein hai aur Hindi, Hinglish ya English bolta hai.
Hamesha SIRF ek JSON object wapas do, is format mein:
{"action":"chat|open_app|whatsapp_chat|whatsapp_call|whatsapp_video|phone_call|conference|youtube",
 "app":"app ka naam English mein (sirf open_app ke liye)",
 "contacts":["naam English letters mein, jaise phone mein save hota hai"],
 "channel":"YouTube channel ka naam (sirf youtube ke liye)",
 "query":"YouTube mein kya dhundhna hai ya video ka naam, agar bola ho",
 "lang":"hi ya en",
 "reply":"user ke liye chhota bolne wala jawab"}

Niyam:
- open_app: koi bhi app kholne ko bole. "app" mein uska naam do (WhatsApp, Camera, Settings, Chrome...).
- whatsapp_chat: kisi ka WhatsApp chat kholna. contacts mein ek naam.
- whatsapp_call / whatsapp_video: WhatsApp par us insaan ko voice / video call.
- phone_call: normal phone call. contacts mein ek naam.
- conference: 2 ya zyada logon ko conference call. contacts mein sab naam.
- youtube: YouTube kholna, channel ya video dhundhna.
- chat: baaki sab, yaani sawal-jawab, baatein, greeting. contacts khali rakho.
- Agar user Hindi mein bole to "lang":"hi" aur reply DEVANAGARI mein likho (taaki awaaz Hindi mein sahi bole). Agar English mein bole to "lang":"en" aur reply English mein.
- Hinglish mein bole to Hindi (Devanagari) mein jawab do, lekin English shabd Latin letters mein likh sakte ho.
- reply chhota rakho (1-3 vaakya), kyunki wo bolkar sunaya jaayega. Koi markdown, emoji ya star mat use karo.
- Kaam wale actions mein reply mein bas ek chhota confirm do, jaise "ठीक है, WhatsApp खोल रहा हूँ।".
- Pata na ho to ईमानदारी se bolo ki pata nahi.
"""

    fun ask(apiKey: String, model: String, userText: String): JSONObject {
        history.add("user" to userText)
        while (history.size > 8) history.removeAt(0)

        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.6))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) {
            history.removeAt(history.size - 1)
            return JSONObject()
                .put("action", "chat").put("lang", "hi")
                .put("reply", if (code == 429) "अभी बहुत सारे सवाल हो गए, थोड़ी देर बाद फिर पूछिए।" else "AI से जुड़ने में दिक्कत आई। अपनी API key और internet check कीजिए।")
        }

        return try {
            val raw = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val obj = JSONObject(raw.trim().removePrefix("```json").removeSuffix("```").trim())
            history.add("model" to raw)
            obj
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            JSONObject().put("action", "chat").put("lang", "hi").put("reply", "माफ़ कीजिए, मैं समझ नहीं पाया। फिर से बोलिए।")
        }
    }
}
