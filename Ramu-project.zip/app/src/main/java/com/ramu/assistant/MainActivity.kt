package com.ramu.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var geminiKey: EditText
    private lateinit var geminiModel: EditText
    private lateinit var ytKey: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ramu", MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 60)
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, 28, 0, 6) }
        fun btn(t: String, click: () -> Unit) = Button(this).apply { text = t; setOnClickListener { click() } }

        col.addView(TextView(this).apply { text = "Ramu 🎙️"; textSize = 28f })

        col.addView(label("1) Gemini API key (free, aistudio.google.com se)"))
        geminiKey = EditText(this).apply {
            setText(prefs.getString("gemini_key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        col.addView(geminiKey)

        col.addView(label("Gemini model ka naam"))
        geminiModel = EditText(this).apply { setText(prefs.getString("gemini_model", "gemini-2.5-flash")) }
        col.addView(geminiModel)

        col.addView(label("YouTube API key (zaroori nahi; channel ka latest video seedha kholne ke liye)"))
        ytKey = EditText(this).apply {
            setText(prefs.getString("yt_key", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        col.addView(ytKey)

        col.addView(btn("2) Keys save karo") { save() })
        col.addView(btn("3) \"Ramu\" shabd ka model download karo (ek baar)") { downloadModel() })
        col.addView(btn("4) Permissions do (mic, contacts, call)") { askPermissions() })
        col.addView(btn("5) \"Display over other apps\" allow karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        col.addView(btn("6) Accessibility on karo (Ramu service)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        col.addView(btn("7) Battery optimization band karo") {
            val pm = getSystemService(PowerManager::class.java)
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
        col.addView(btn("▶ Ramu chalu karo") { startRamu() })
        col.addView(btn("■ Ramu band karo") { stopService(Intent(this, RamuService::class.java)); say("Ramu band.") })

        status = TextView(this).apply { textSize = 15f; setPadding(0, 30, 0, 0) }
        col.addView(status)

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
        say(if (ModelStore.isReady(this)) "Model taiyaar hai." else "Model abhi download nahi hua.")
    }

    private fun say(t: String) { runOnUiThread { status.text = t } }

    private fun save() {
        getSharedPreferences("ramu", MODE_PRIVATE).edit()
            .putString("gemini_key", geminiKey.text.toString().trim())
            .putString("gemini_model", geminiModel.text.toString().trim().ifBlank { "gemini-2.5-flash" })
            .putString("yt_key", ytKey.text.toString().trim())
            .apply()
        say("Save ho gaya.")
    }

    private fun downloadModel() {
        say("Shuru...")
        Thread {
            try { ModelStore.download(this) { say(it) } }
            catch (e: Exception) { say("Download fail: ${e.message}. Internet check karke dobara dabaao.") }
        }.start()
    }

    private fun askPermissions() {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, list.toTypedArray(), 1)
    }

    private fun startRamu() {
        save()
        if (!ModelStore.isReady(this)) { say("Pehle step 3 (model download) karo."); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            say("Pehle step 4 (permissions) do."); return
        }
        if (geminiKey.text.isBlank()) { say("Pehle Gemini API key daalo."); return }
        ContextCompat.startForegroundService(this, Intent(this, RamuService::class.java))
        say("Ramu chalu. Ab \"Ramu\" bolkar dekho.")
    }
}
