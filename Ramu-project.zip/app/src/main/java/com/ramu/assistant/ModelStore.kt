package com.ramu.assistant

import android.content.Context
import java.io.File
import java.net.URL
import java.util.zip.ZipInputStream

/** "Ramu" shabd pehchanne wala chhota offline Vosk model (sirf ek baar download hota hai). */
object ModelStore {
    private const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip"
    private const val FOLDER = "vosk-model-small-en-in-0.4"

    fun modelDir(ctx: Context) = File(ctx.filesDir, "vosk/$FOLDER")
    fun isReady(ctx: Context) = File(modelDir(ctx), "am").exists()

    fun download(ctx: Context, progress: (String) -> Unit) {
        val root = File(ctx.filesDir, "vosk").apply { mkdirs() }
        progress("Model download ho raha hai (~36 MB)...")
        val conn = URL(URL_ZIP).openConnection()
        conn.connectTimeout = 20000; conn.readTimeout = 60000
        ZipInputStream(conn.getInputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val out = File(root, entry.name)
                if (!out.canonicalPath.startsWith(root.canonicalPath)) throw SecurityException("bad zip")
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zip.copyTo(it) }
                }
                entry = zip.nextEntry
            }
        }
        progress("Model taiyaar hai.")
    }
}
