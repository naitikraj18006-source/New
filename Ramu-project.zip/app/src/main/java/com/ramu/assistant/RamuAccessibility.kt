package com.ramu.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Sirf tab kaam karta hai jab Ramu ne koi kaam maanga ho:
 *  - WhatsApp chat khulne ke baad "Voice call" / "Video call" button dabana (agar seedha call na lagi ho)
 *  - Dusri call lagne ke baad "Merge" dabana (conference call)
 */
class RamuAccessibility : AccessibilityService() {

    companion object {
        @Volatile var pending: String? = null   // "wa_voice", "wa_video", "merge"
        @Volatile var pendingUntil: Long = 0L

        fun request(kind: String, seconds: Int = 20) {
            pending = kind
            pendingUntil = System.currentTimeMillis() + seconds * 1000L
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val kind = pending ?: return
        if (System.currentTimeMillis() > pendingUntil) { pending = null; return }
        val root = rootInActiveWindow ?: return

        val labels = when (kind) {
            "wa_voice" -> listOf("voice call")
            "wa_video" -> listOf("video call")
            "merge" -> listOf("merge calls", "merge")
            else -> return
        }
        if (kind.startsWith("wa_") && root.packageName?.toString() != "com.whatsapp") return

        for (label in labels) {
            val node = findByLabel(root, label) ?: continue
            if (clickNode(node)) {
                pending = null
                return
            }
        }
    }

    private fun findByLabel(node: AccessibilityNodeInfo?, label: String): AccessibilityNodeInfo? {
        if (node == null) return null
        val d = node.contentDescription?.toString()?.lowercase()
        val t = node.text?.toString()?.lowercase()
        if ((d != null && d.contains(label)) || (t != null && t.contains(label))) return node
        for (i in 0 until node.childCount) {
            val r = findByLabel(node.getChild(i), label)
            if (r != null) return r
        }
        return null
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
