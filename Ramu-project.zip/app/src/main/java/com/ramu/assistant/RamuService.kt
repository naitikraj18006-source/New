package com.ramu.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Bundle
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.RecognitionListener as VoskListener

/**
 * Hamesha chalne wali service.
 *  1) Vosk sirf "ramu" shabd sunta hai (offline, kuch save/send nahi hota).
 *  2) "Ramu" sunte hi beep -> Android ka speech recogniser aapka sawal text banata hai (hi-IN).
 *  3) Sirf text Gemini ko jaata hai -> jawab bolta hai / kaam karta hai -> wapas step 1.
 */
class RamuService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var vosk: SpeechService? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var speaker: Speaker
    private lateinit var actions: Actions
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        actions = Actions(this)
        speaker = Speaker(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startForegroundNow()
        if (!running) {
            running = true
            Thread { loadModelAndListen() }.start()
        }
        return START_STICKY
    }

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("ramu", "Ramu", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = android.app.PendingIntent.getService(
            this, 0, Intent(this, RamuService::class.java).setAction("STOP"),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, "ramu")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Ramu सुन रहा है")
            .setContentText("\"Ramu\" बोलिए")
            .setOngoing(true)
            .addAction(0, "Band karo", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1, n)
    }

    private fun loadModelAndListen() {
        try {
            if (model == null) model = Model(ModelStore.modelDir(this).absolutePath)
            main.post { startWakeWord() }
        } catch (e: Exception) {
            main.post { speaker.speak("Model load नहीं हुआ। App खोलकर model download कीजिए।") { stopSelf() } }
        }
    }

    // ---------- 1) Wake word ----------
    private fun startWakeWord() {
        if (!running) return
        val m = model ?: return
        stopWakeWord()
        val grammar = "[\"ramu\", \"rammu\", \"ramoo\", \"ramo\", \"ram\", \"[unk]\"]"
        val rec = Recognizer(m, 16000.0f, grammar)
        vosk = SpeechService(rec, 16000.0f).also {
            it.startListening(object : VoskListener {
                private fun check(json: String) {
                    val t = JSONObject(json).let { j -> j.optString("text", j.optString("partial", "")) }
                    if (t.contains("ramu") || t.contains("rammu") || t.contains("ramoo") || t.contains("ramo")) {
                        main.post { onWake() }
                    }
                }
                override fun onPartialResult(hypothesis: String?) { hypothesis?.let { check(it) } }
                override fun onResult(hypothesis: String?) { hypothesis?.let { check(it) } }
                override fun onFinalResult(hypothesis: String?) {}
                override fun onError(exception: Exception?) { main.postDelayed({ startWakeWord() }, 1500) }
                override fun onTimeout() { main.post { startWakeWord() } }
            })
        }
    }

    private fun stopWakeWord() {
        vosk?.stop(); vosk?.shutdown(); vosk = null
    }

    // ---------- 2) Sawal sunna ----------
    private fun onWake() {
        stopWakeWord()
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        main.postDelayed({ listenCommand() }, 250)
    }

    private fun listenCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speaker.speak("इस phone पर speech recognition उपलब्ध नहीं है।") { startWakeWord() }
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) startWakeWord() else handle(text)
                }
                override fun onError(error: Int) { startWakeWord() }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            sr.startListening(i)
        }
    }

    // ---------- 3) Samajhna, karna, bolna ----------
    private fun handle(text: String) {
        val prefs = getSharedPreferences("ramu", MODE_PRIVATE)
        val key = prefs.getString("gemini_key", "") ?: ""
        val model = prefs.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        val yt = prefs.getString("yt_key", "") ?: ""
        if (key.isBlank()) {
            speaker.speak("पहले app में Gemini API key डालिए।") { startWakeWord() }
            return
        }
        Thread {
            val cmd = Brain.ask(key, model, text)
            val override = try { actions.run(cmd, yt) } catch (e: SecurityException) {
                "इस काम की permission नहीं मिली। App खोलकर permissions दीजिए।"
            } catch (e: Exception) { "यह काम नहीं हो पाया।" }
            val say = override ?: cmd.optString("reply", "")
            main.post { speaker.speak(say) { startWakeWord() } }
        }.start()
    }

    override fun onDestroy() {
        running = false
        stopWakeWord()
        recognizer?.destroy()
        speaker.shutdown()
        super.onDestroy()
    }
}
