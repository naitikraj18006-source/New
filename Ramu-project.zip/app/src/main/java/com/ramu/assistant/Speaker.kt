package com.ramu.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Jawab ko hisson mein baantkar bolta hai: Devanagari hissa Hindi voice mein,
 * Latin (English) hissa English-India voice mein. Isse Alexa jaisi sahi tone aati hai.
 */
class Speaker(context: Context, onReady: () -> Unit = {}) {

    private var ready = false
    private var onDone: (() -> Unit)? = null
    private var lastId = ""
    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        ready = status == TextToSpeech.SUCCESS
        if (ready) onReady()
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == lastId) onDone?.invoke()
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == lastId) onDone?.invoke()
            }
        })
    }

    private fun isDevanagari(c: Char) = c in 'ऀ'..'ॿ'
    private fun isLetter(c: Char) = c.isLetter()

    private fun split(text: String): List<Pair<String, Boolean>> {
        val runs = ArrayList<Pair<String, Boolean>>()
        val sb = StringBuilder()
        var hindi: Boolean? = null
        for (c in text) {
            if (isLetter(c)) {
                val h = isDevanagari(c)
                if (hindi != null && hindi != h && sb.isNotBlank()) {
                    runs.add(sb.toString() to hindi!!)
                    sb.clear()
                }
                hindi = h
            }
            sb.append(c)
        }
        if (sb.isNotBlank()) runs.add(sb.toString() to (hindi ?: false))
        return runs
    }

    private var runs: List<Pair<String, Boolean>> = emptyList()
    private var index = 0
    private var finishedCb: (() -> Unit)? = null

    fun speak(text: String, finished: () -> Unit) {
        if (!ready || text.isBlank()) { finished(); return }
        tts.stop()
        runs = split(text)
        index = 0
        finishedCb = finished
        // Har hissa ek-ek karke bolte hain, taaki bolne se theek pehle uski sahi bhasha set ho.
        onDone = { next() }
        lastId = "ramu_run"
        next()
    }

    private fun next() {
        if (index >= runs.size) {
            android.os.Handler(android.os.Looper.getMainLooper()).post { finishedCb?.invoke() }
            return
        }
        val (part, hindi) = runs[index++]
        tts.language = if (hindi) Locale("hi", "IN") else Locale("en", "IN")
        tts.speak(part, TextToSpeech.QUEUE_FLUSH, null, "ramu_run")
    }

    fun shutdown() { tts.stop(); tts.shutdown() }
}
